const splash=document.getElementById('siteSplash');
if(splash){
  const seen=sessionStorage.getItem('lamaroSplashSeen');
  if(seen){ splash.classList.add('hide'); }
  else {
    sessionStorage.setItem('lamaroSplashSeen','1');
    window.setTimeout(()=>splash.classList.add('hide'),2200);
  }
}
const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting)entry.target.classList.add('visible')}),{threshold:.08});document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
const path=location.pathname.split('/').pop()||'index.html';const current=path==='index.html'?'home':path.replace('.html','');document.querySelectorAll(`[data-nav="${current}"]`).forEach(el=>el.classList.add('active'));
const menu=document.querySelector('.menu'),panel=document.querySelector('.mobileMenu'),shade=document.querySelector('.menuShade'),close=document.querySelector('.closeMenu');function setMenu(open){panel?.classList.toggle('open',open);shade?.classList.toggle('open',open);document.body.style.overflow=open?'hidden':'';menu?.setAttribute('aria-expanded',String(open));panel?.setAttribute('aria-hidden',String(!open))}menu?.addEventListener('click',()=>setMenu(true));close?.addEventListener('click',()=>setMenu(false));shade?.addEventListener('click',()=>setMenu(false));panel?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setMenu(false)));document.addEventListener('keydown',e=>{if(e.key==='Escape')setMenu(false)});
const fallback='assets/store.svg';document.querySelectorAll('img').forEach(img=>img.addEventListener('error',()=>{if(!img.dataset.fallback){img.dataset.fallback='1';img.src=fallback;img.style.objectFit='contain';img.style.padding='30px'}},{once:true}));
document.querySelectorAll('.gallery img,.cardImg img,.heroCard img,.imageFrame img').forEach(img=>img.addEventListener('click',()=>{const box=document.createElement('div');box.className='lightbox';box.innerHTML=`<button aria-label="Close">×</button><img src="${img.src}" alt="${img.alt||'Lamaro Studio'}"><span>Lamaro Studio</span>`;document.body.appendChild(box);requestAnimationFrame(()=>box.classList.add('show'));box.addEventListener('click',e=>{if(e.target===box||e.target.tagName==='BUTTON')box.remove()})}));

// Scroll-controlled cinematic basket sequence
(()=>{
  const canvas=document.getElementById('basketAnimation');
  const stage=document.querySelector('.basket-stage');
  if(!canvas||!stage)return;
  const ctx=canvas.getContext('2d',{alpha:false});
  const total=240, folder='assets/basket-animation/';
  const frames=new Array(total); let current=-1, ticking=false;
  const pad=n=>String(n).padStart(3,'0');
  const frameUrl=i=>folder+'ezgif-frame-'+pad(i+1)+'.jpg';
  const sizeCanvas=()=>{
    const w=Math.min(canvas.parentElement?.clientWidth||760,760), h=Math.round(w*9/16), d=Math.min(devicePixelRatio||1,2);
    canvas.width=w*d; canvas.height=h*d; canvas.style.aspectRatio='16 / 9';
    ctx.setTransform(d,0,0,d,0,0); return [w,h];
  };
  const draw=i=>{
    i=Math.max(0,Math.min(total-1,i)); const img=frames[i];
    if(!img||!img.complete||!img.naturalWidth)return false;
    const [w,h]=sizeCanvas(); ctx.clearRect(0,0,w,h); ctx.drawImage(img,0,0,w,h); current=i; return true;
  };
  const load=i=>{
    if(i<0||i>=total||frames[i])return;
    const img=new Image(); img.decoding='async'; img.onload=()=>{if(i===0||i===current)draw(i)}; img.src=frameUrl(i); frames[i]=img;
  };
  load(0); for(let i=1;i<30;i++)load(i);
  const progress=()=>{const r=stage.getBoundingClientRect();const travel=Math.max(1,stage.offsetHeight-innerHeight);return Math.max(0,Math.min(1,-r.top/travel));};
  const update=()=>{ticking=false;const i=Math.round(progress()*(total-1));for(let d=-12;d<=30;d++)load(i+d);if(!draw(i)){for(let d=1;d<total;d++){if(draw(i-d)||draw(i+d))break;}}};
  const onScroll=()=>{if(!ticking){ticking=true;requestAnimationFrame(update)}};
  addEventListener('scroll',onScroll,{passive:true}); addEventListener('resize',()=>{current=-1;update()},{passive:true});
  setTimeout(update,60);
})();
