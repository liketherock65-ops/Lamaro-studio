const splash=document.getElementById('siteSplash');
if(splash){
  const seen=sessionStorage.getItem('lamaroSplashSeen');
  if(seen){ splash.classList.add('hide'); }
  else {
    sessionStorage.setItem('lamaroSplashSeen','1');
    window.setTimeout(()=>splash.classList.add('hide'),2200);
  }
}
const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting)entry.target.classList.add('visible')}),{threshold:.08});document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));
const path=location.pathname.split('/').pop()||'index.html';const current=path==='index.html'?'home':path.replace('.html','');document.querySelectorAll(`[data-nav="${current}"]`).forEach(el=>el.classList.add('active'));
const menu=document.querySelector('.menu'),panel=document.querySelector('.mobileMenu'),shade=document.querySelector('.menuShade'),close=document.querySelector('.closeMenu');function setMenu(open){panel?.classList.toggle('open',open);shade?.classList.toggle('open',open);document.body.style.overflow=open?'hidden':'';menu?.setAttribute('aria-expanded',String(open));panel?.setAttribute('aria-hidden',String(!open))}menu?.addEventListener('click',()=>setMenu(true));close?.addEventListener('click',()=>setMenu(false));shade?.addEventListener('click',()=>setMenu(false));panel?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setMenu(false)));document.addEventListener('keydown',e=>{if(e.key==='Escape')setMenu(false)});
const fallback='assets/store.svg';document.querySelectorAll('img').forEach(img=>img.addEventListener('error',()=>{if(!img.dataset.fallback){img.dataset.fallback='1';img.src=fallback;img.style.objectFit='contain';img.style.padding='30px'}},{once:true}));
document.querySelectorAll('.gallery img,.cardImg img,.heroCard img,.imageFrame img').forEach(img=>img.addEventListener('click',()=>{const box=document.createElement('div');box.className='lightbox';box.innerHTML=`<button aria-label="Close">×</button><img src="${img.src}" alt="${img.alt||'Lamaro Studio'}"><span>Lamaro Studio</span>`;document.body.appendChild(box);requestAnimationFrame(()=>box.classList.add('show'));box.addEventListener('click',e=>{if(e.target===box||e.target.tagName==='BUTTON')box.remove()})}));

// Scroll-controlled cinematic basket sequence
(()=>{
  const canvas=document.getElementById('basketAnimation');
  const stage=document.querySelector('.basket-stage');
  if(!canvas||!stage) return;
  const ctx=canvas.getContext('2d');
  const total=240;
  const folder='assets/basket-animation/';
  const frames=new Array(total);
  let current=-1, loaded=0, ticking=false;
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const pad=n=>String(n).padStart(3,'0');
  const frameUrl=i=>folder+'ezgif-frame-'+pad(i+1)+'.jpg';
  const draw=(i)=>{
    const img=frames[i]; if(!img||!img.complete||!img.naturalWidth)return;
    if(i===current)return; current=i;
    const ratio=img.naturalWidth/img.naturalHeight;
    const cssW=Math.min(canvas.clientWidth||760,760);
    const cssH=cssW/ratio;
    const dpr=Math.min(window.devicePixelRatio||1,2);
    canvas.width=Math.round(cssW*dpr); canvas.height=Math.round(cssH*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,cssW,cssH); ctx.drawImage(img,0,0,cssW,cssH);
  };
  const preload=(start,end)=>{
    for(let i=start;i<end;i++){
      if(frames[i])continue;
      const img=new Image();
      img.decoding='async';
      img.onload=()=>{loaded++; if(i===0)draw(0);};
      img.src=frameUrl(i); frames[i]=img;
    }
  };
  preload(0,Math.min(total,36));
  const getProgress=()=>{
    const rect=stage.getBoundingClientRect();
    const travel=Math.max(1,stage.offsetHeight-window.innerHeight);
    return Math.max(0,Math.min(1,-rect.top/travel));
  };
  const update=()=>{
    ticking=false;
    const index=Math.round(getProgress()*(total-1));
    const from=Math.max(0,index-8), to=Math.min(total,index+18);
    preload(from,to);
    draw(index);
  };
  const onScroll=()=>{if(!ticking){ticking=true;requestAnimationFrame(update);}};
  window.addEventListener('scroll',onScroll,{passive:true});
  window.addEventListener('resize',()=>{current=-1;update();},{passive:true});
  if(reduced){preload(0,1);setTimeout(()=>draw(0),100);return;}
  setTimeout(update,120);
})();
